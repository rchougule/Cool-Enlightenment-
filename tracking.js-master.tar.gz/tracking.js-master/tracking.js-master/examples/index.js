function sendData(status,color){

	var settings = {
  "async": true,
  "crossDomain": true,
  "url": "http://localhost:8080/",
  "method": "POST",
  "headers": {
    "name": color,
    "status": status,
    "content-type": "application/x-www-form-urlencoded"
  }
}

	$.ajax(settings).done(function (response) {
	  console.log(response);
	});
}